(function(){
    $(document).ready(function(){
        // document.body.contentEditable = "true"
        /*//发消息
        var bac = chrome.extension.connect({name: "bgAndCon"});
        bac.postMessage({joke: "Knock knock"});*/
        //接收消息
        chrome.extension.onConnect.addListener(function(cab) {
            cab.onMessage.addListener(function(msg) {
                 // var t_titles = document.getElementByTagName("title") ;
                 var tabselected = document.getElementsByClassName('tabs-mod__selected___3F9lM')[0];
                 var title = tabselected.getElementsByClassName('nav-mod__text___3O7jT')[0].textContent
                 var items = document.getElementsByClassName('index-mod__order-container___1ur4- js-order-container');
                 var length = items.length;
                 var str = '订单号,时间,店铺名称,商品名称,价格,数量,付款金额,订单状态\n';
                 var page = document.getElementsByClassName(' pagination-item-active')[0].textContent;
                 for (i = 0;i < length; i++) {

                    var dict = {};

                    var item = items[i];

                    //订单号
                    var orderitem = item.getElementsByClassName('bought-wrapper-mod__head-info-cell___29cDO')[0];
                    var spans = orderitem.getElementsByTagName('span');
                    var ordernumber =spans[spans.length-1].textContent;



                    //时间
                    var time = item.getElementsByClassName('bought-wrapper-mod__create-time___yNWVS')[0].textContent;
                    
                    //店铺名称
                    var shopname= item.getElementsByClassName('seller-mod__name___37vL8')[0].textContent;


                    //商品名称
                    var nameitem = item.getElementsByClassName('ml-mod__container___dVhLg production-mod__production___1MKah')[0];
                    var namediv = nameitem.getElementsByTagName('div')[1];
                    var namep = namediv.getElementsByTagName('p')[0];
                    var name = namep.getElementsByTagName('span')[1].textContent;

                    //价格
                    var priceitem = item.getElementsByClassName('price-mod__price___157jz')[0];
                    var pricespans = priceitem.getElementsByTagName('span');
                    var price = pricespans[pricespans.length-1].textContent;


                    //数量
                    var numitem = item.getElementsByClassName('sol-mod__no-br___1PwLO')[2];
                    var number = numitem.getElementsByTagName('p')[0].textContent;

                    //付款

                    var payitem = item.getElementsByClassName('price-mod__price___157jz')[1];
                    var payspans = payitem.getElementsByTagName('span');
                    var payment = payspans[payspans.length-1].textContent;


                    //状态
                    var tds = item.getElementsByTagName('td');
                    var statusitem = tds[9];
                    var status = statusitem.getElementsByClassName('text-mod__link___1dpU2')[0].textContent;

                    str += `${ordernumber + '\t'},`;   
                    str += `${time + '\t'},`;   
                    str += `${shopname + '\t'},`;  
                    str += `${name + '\t'},`;    
                    str += `${price + '\t'},`; 
                    str += `${number + '\t'},`;  
                    str += `${payment + '\t'},`;   
                    str += `${status + '\t'},`;      

                     str += '\n';


                 }

                
                 

                 let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(str);
                  //通过创建a标签实现
                  var link = document.createElement("a");
                  link.href = uri;
                  var mydate = new Date();

                  //对下载的文件命名
                  link.download =  mydate.getFullYear() +'-'+ mydate.getMonth()+'-'+mydate.getDate() + title+ '第'+page+'页'+'.csv';
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);

                // if(msg.flag){
                //     $("body").find("*").mouseenter(function(){
                //         event.stopPropagation();
                //         $(this).css({"box-shadow":"0 0 5px 1px #3AB2FF"});
                //         $(this).one("click", function(){
                //             event.stopPropagation();
                //             $(this).hide();
                //             return false;
                //         })
                //     });
                //     $("body").find("*").mouseout(function(){
                //         event.stopPropagation();
                //         $(this).css("box-shadow", "none");
                //     })
                // } else {
                //     $("body").find("*").unbind("mouseenter").unbind("mouseout").unbind("click");
                // }
            })
        })
        /*chrome.extension.onConnect.addListener(function(cab) {
            console.log("AAA")
            cab.onMessage.addListener(function(msg) {
                console.log(msg.greeting);
                console.log("BBB")
            })
        })*/
    });
})();